﻿using CrudApplication.Models.ViewModel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrudApplication.Controllers.Account
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

       


        public IActionResult Login()
        {
            return View();

        }
        [HttpPost]


        public IActionResult Login(LoginSignUpViewModel model)
        {
            return View();

        }



        public IActionResult SignUp()
        {
            return View();

        }


        [HttpPost]
        public IActionResult SignUp(SignUpUserViewModel model)
        {
            if (ModelState.IsValid) 
            { 
               return View(model);
            }
            
            else
            {
                TempData["errorMessage"] = "Empty form can't be submitted!";
                return View(model);
            }
            

        }

    }
}
